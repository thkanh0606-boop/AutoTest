from database.engine import engine, Base, SessionLocal
from database.models import Website, Page, Element, TestCase
from core.config import Config

def init_db():
    Base.metadata.create_all(bind=engine)
    print("Đã tạo cấu trúc cơ sở dữ liệu thành công.")

def seed_pcm_data():
    db = SessionLocal()
    
    if db.query(Website).first():
        print("Dữ liệu đã được seed từ trước! Hãy xóa file autotest.db nếu muốn seed lại.")
        db.close()
        return

    # 1. Khởi tạo Website
    pcm_web = Website(name="PCM System", base_url=Config.BASE_URL)
    db.add(pcm_web)
    db.commit()

    # 2. Khởi tạo 6 Pages chuẩn theo tài liệu SRS
    pages_data = [
        {"name": "Đăng nhập", "url_path": "/login"},
        {"name": "Bảng điều khiển", "url_path": "/dashboard"},
        {"name": "Quản lý đặt xe", "url_path": "/bookings"},
        {"name": "Quản lý xe", "url_path": "/cars"},
        {"name": "Danh mục xe", "url_path": "/catalog"},
        {"name": "Quản lý tài chính", "url_path": "/finance"}
    ]
    
    for p in pages_data:
        db.add(Page(website_id=pcm_web.id, name=p["name"], url_path=p["url_path"]))
    db.commit()

    # 3. Import các Element từ PCMLocators (Mã hóa vào Database)
    # page_id=1 (Đăng nhập), page_id=2 (Bảng điều khiển - Sidebar menu), page_id=3 (Đặt xe)
    elements_data = [
        {"page_id": 1, "name": "Email Input", "locator_type": "XPATH", "locator_value": "//input[@name='username' or @name='email' or @id='username' or @type='text' or @type='email']"},
        {"page_id": 1, "name": "Password Input", "locator_type": "XPATH", "locator_value": "//input[@type='password']"},
        {"page_id": 1, "name": "Submit Button", "locator_type": "XPATH", "locator_value": "//button[@type='submit'] | //input[@type='submit'] | //button[contains(text(), 'Đăng nhập') or contains(text(), 'Log in')]"},
        
        {"page_id": 2, "name": "Menu Xe", "locator_type": "XPATH", "locator_value": "//li[contains(@data-menu-id, '/cars') and not(contains(@data-menu-id, '/catalog'))] | //span[text()='Xe']/parent::li"},
        {"page_id": 2, "name": "Menu Đặt xe", "locator_type": "XPATH", "locator_value": "//li[contains(@data-menu-id, '/bookings')] | //span[text()='Đặt xe']/parent::li"},
        
        {"page_id": 3, "name": "Booking Table Rows", "locator_type": "XPATH", "locator_value": "//table//tbody/tr | //div[contains(@class, 'ant-table-row')] | //li[contains(@class, 'ant-menu-item')]"}
    ]
    for e in elements_data:
        db.add(Element(**e))

    # 4. Khởi tạo Test Case
    test_cases_data = [
        {
            "page_id": 1, 
            "name": "TC01 - Đăng nhập thành công", 
            "description": "Access the website. Nhập email hợp lệ vào Email Input. Access the website. Nhập mật khẩu hợp lệ vào Password Input. Access the website. Click Submit Button và kiểm tra hệ thống chuyển sang Bảng điều khiển."
        },
        {
            "page_id": 1, 
            "name": "TC02 - Đăng nhập thất bại (Sai mật khẩu)", 
            "description": "Access the website. Nhập email đúng. Access the website. Nhập mật khẩu sai. Access the website. Click Submit Button và kiểm tra thông báo cảnh báo hiển thị."
        },
        {
            "page_id": 3,
            "name": "TC03 - Kiểm tra bảng dữ liệu Đặt xe",
            "description": "Access the website. Từ Bảng điều khiển, click vào Menu Đặt xe. Access the website. Đếm số lượng Booking Table Rows để xác minh dữ liệu đã được tải thành công."
        }
    ]
    for tc in test_cases_data:
        db.add(TestCase(**tc))

    db.commit()
    db.close()
    print("Đã seed dữ liệu PCM thành công: 6 Pages, 6 Elements, 3 Test Cases.")

if __name__ == "__main__":
    init_db()
    seed_pcm_data()